gnome-terminal -e gulp watch &&
npm start
